from django.shortcuts import render
from .models import Product, ProductCategory, Order
from .serializers import ProductSerializer, ProductCategorySerializer
from rest_framework.views import APIView
from rest_framework import permissions
from drf_yasg.utils import swagger_auto_schema
from rest_framework.response import Response
from rest_framework import status
from drf_yasg import openapi
import json


class ProductCategoryList(APIView):
    permission_classes = [permissions.IsAuthenticated]

    @swagger_auto_schema(responses={200: ProductCategorySerializer(many=True)})
    def get(self, request, format=None):
        """ Maxsulotlar ro'yxati [Group: Any] """

        product_category_list = ProductCategory.objects.all()
        product_categry_serializers = ProductCategorySerializer(product_category_list, many=True)

        return Response(
            product_categry_serializers.data,
            status=status.HTTP_200_OK
        )


class ProductList(APIView):
    permission_classes = [permissions.IsAuthenticated]
    category_id = openapi.Parameter('category_id',
                openapi.IN_QUERY,
                description="Product category id",
                type=openapi.TYPE_INTEGER)

    @swagger_auto_schema(
                responses={200: ProductSerializer(many=True)},
                manual_parameters=[category_id]
                )
    def get(self, request, format=None):
        """ Maxsulotlar ro'yxati [Group: Any] """
        try:
            category_id = request.GET['category_id']
        except:
            return Response(
                        {"detail": "category_id cannot be empty"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        product_list = Product.objects.filter(category__id=category_id)
        product_serializers = ProductSerializer(product_list, many=True)

        return Response(
            product_serializers.data,
            status=status.HTTP_200_OK
        )


class OrderView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    order_list = openapi.Parameter('order_list',
                openapi.IN_FORM,
                description="Order list",
                type=openapi.TYPE_STRING)
    
    geo_location = openapi.Parameter('geo_location',
                openapi.IN_FORM,
                description="User geo location",
                type=openapi.TYPE_STRING)

    def validate_datas(self, order, location):
        """ Validating order and geo location """

        order_dictionary = json.loads(order)

        for item in order_dictionary:
            try:
                Product.objects.get(id=int(item))
            except:
                return False

        return True

    @swagger_auto_schema(manual_parameters=[order_list, geo_location],)
    def post(self, request, format=None):
        """ Maxsularni buyurtma qilish [Group: Any]
        ---
        Talab etiladigan ma'lumot turi

        {
            maxsulot_id: maxsulot_soni,
            maxsulot_id: maxsulot_soni,
            maxsulot_id: maxsulot_soni,
            maxsulot_id: maxsulot_soni,
            maxsulot_id: maxsulot_soni,
            ...
        }
        """

        try:
            order_list = request.POST['order_list']
            geo_location = request.POST['geo_location']
        except:
            return Response(
                        {"detail": "order_list or geo_location cannot be empty"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        if not self.validate_datas(order_list, geo_location):
            return Response(
                        {"detail": "order_list or geo_location is not valid"},
                        status=status.HTTP_400_BAD_REQUEST
                    )

        order = Order(cart=order_list, address=geo_location, geo_location_point=geo_location)
        order.save()

        return Response(
            {"order_id": order.id},
            status=status.HTTP_200_OK
        )


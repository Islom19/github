from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator

from .managers import CustomUserManager


class User(AbstractUser):
    username = models.CharField('First name', max_length=20, unique=False)
    last_name = models.CharField(max_length=20)

    email = models.EmailField('email address', unique=True)
    phone_regex = RegexValidator(regex=r'^9{2}8\d{9}$',
                                 message="""Phone number must be entered in the
                                 format: '998997778899'. 12 digits allowed.""")
    phone = models.CharField(validators=[phone_regex], max_length=12,
                            unique=True, blank=False, null=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    USERNAME_FIELD = 'phone'
    REQUIRED_FIELDS = ['username', 'last_name',
                       'email', 'password']

    def __str__(self):
        return "{} {}".format(self.username, self.last_name)

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'


class Branch(models.Model):
    name = models.CharField("Branch name", max_length=100)
    address = models.CharField("Address", max_length=100)
    geo_location_point = models.CharField("Geo location name", max_length=100)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Branch'
        verbose_name_plural = 'Branches'


class Order(models.Model):
    cart = models.TextField(max_length=5000)
    courier = models.ForeignKey(User, 
                    on_delete=models.SET_NULL, 
                    related_name='order', 
                    blank=True,
                    null=True)

    branch = models.ForeignKey(Branch, 
                    on_delete=models.SET_NULL, 
                    related_name='orders', 
                    blank=True,
                    null=True)

    address = models.CharField(max_length=100)
    geo_location_point = models.CharField(max_length=100)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.id

    class Meta:
        verbose_name = 'Order'
        verbose_name_plural = 'Orders'


class Status(models.Model):
    status = models.CharField("Branch name", max_length=100)
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="status")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Status'
        verbose_name_plural = 'Status'


class ProductCategory(models.Model):
    name = models.CharField(max_length=100)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Product category'
        verbose_name_plural = 'Product categories'


class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(decimal_places=10, max_digits=100)
    category = models.ManyToManyField(
                    ProductCategory, 
                    related_name='product')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Product'
        verbose_name_plural = 'Products'

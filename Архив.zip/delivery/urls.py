from django.urls import path
from .views import ProductList, ProductCategoryList, OrderView


urlpatterns = [
    path('products/', ProductList.as_view(), name='Product list'),
    path('product-categories/', ProductCategoryList.as_view(), name='Product Category list'),
    path('pass-order/', OrderView.as_view(), name='Order'),
]

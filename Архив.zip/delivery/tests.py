from django.shortcuts import render


class PortalDetail(APIView):
    permission_classes = [permissions.IsAuthenticated]
    page = openapi.Parameter('page',
                    openapi.IN_QUERY,
                    description="Page number(default=1)",
                    type=openapi.TYPE_INTEGER)

    def get_object(self, chat_id):
        murojaats = Murojaat.objects.filter(chat_id=chat_id).order_by('-id')
        if Murojaats.count() != 0:
            return Murojaats
        else:
            raise Http404

    def get_paginated(self, queryset, page):
        self.paginator = Paginator(queryset, 10)
        try:
            return self.paginator.page(page)
        except EmptyPage:
            return self.paginator.page(self.paginator.num_pages)

    @swagger_auto_schema(
        manual_parameters = [page],
        responses={200: PortalSerializer(many=True)})
    def get(self, request, format=None):
        """ Foydalanuvchiga tegishli portal xabarlari [Group: Talaba, Yi] 
        ---
        Foydalanuvchi groupiga bog'liq tarzda qaytariladigan ma'lumotlar turlicha bo'ladi.
        """
        try:
            if request.user.groups.filter(name='yi').exists():
                chat_id = request.GET['chat_id']
            elif request.user.groups.filter(name='talaba').exists():
                chat_id = request.user.id
            else:
                return Response(
                    {"detail": _(
                        "You do not have permission to perform this action.")},
                    status=status.HTTP_403_FORBIDDEN
                )
            portal_messages = self.get_object(chat_id)
            paginated_portal_messages = self.get_paginated(
                portal_messages, request.GET.get('page', 1))
            serializer = PortalDetailSerializer(
                paginated_portal_messages, many=True)
            if int(request.GET.get('page', 1)) in self.paginator.page_range:
                data = {
                    'total_chats': self.paginator.count,
                    'max_per_page': self.paginator.per_page,
                    'page_range': [i for i in self.paginator.page_range],
                    'results': serializer.data
                }
            else:
                data = {
                    'total_chats': self.paginator.count,
                    'max_per_page': self.paginator.per_page,
                    'page_range': [i for i in self.paginator.page_range],
                    'results': []
                }
            return Response(data)
        except:
            return Response(
                {"detail": _("Bad Request.")},
                status=status.HTTP_400_BAD_REQUEST
            )
